import tkinter as tk

class Calculator:
    def __init__(self, master):
        self.master = master
        self.master.title("Calculator")

        # Entry for display
        self.display_var = tk.StringVar()
        entry = tk.Entry(self.master, textvariable=self.display_var, font=("Helvetica", 18), justify="right", bd=10)
        entry.grid(row=0, column=0, columnspan=4)

        # Buttons
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]

        row_val, col_val = 1, 0
        for button in buttons:
            tk.Button(self.master, text=button, command=lambda b=button: self.on_button_click(b)).grid(row=row_val, column=col_val, sticky='nsew', ipadx=10, ipady=10)
            col_val += 1
            if col_val > 3:
                col_val = 0
                row_val += 1

        # Configure grid weights
        for i in range(5):
            self.master.grid_rowconfigure(i, weight=1)
            self.master.grid_columnconfigure(i, weight=1)

    def on_button_click(self, button):
        if button == '=':
            try:
                result = eval(self.display_var.get())
                self.display_var.set(result)
            except Exception as e:
                self.display_var.set("Error")
        else:
            current_text = self.display_var.get()
            new_text = current_text + button
            self.display_var.set(new_text)

# Example usage
root = tk.Tk()
app = Calculator(root)
root.mainloop()
